package leasting_3;

 class  Vehicle3 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     int maxspeed;//макс скорость
     int burnup;//расход топлива
     //объявляем метод,вычисляющий пройденный путь.
     //метод принимает парметр interval, задающий время,
     //и не возвращает никакого значения(void)
     void distance(double interval){
         double value=maxspeed*interval;
         System.out.println("пройденый путь, равный"+value+"км.");
     }//distance(double+interval
 }//Vehicle class
class VehicleMetDemo{
    public static void main(String[] args){
        Vehicle3 car=new Vehicle3();
        car.passanegers=2;
        car.wheels=6;
        car.maxspeed=130;
        car.burnup=30;
        //другой экземпляр класса Vehicle
        Vehicle3 bus=new Vehicle3();
        bus.passanegers=45;
        bus.wheels=4;
        bus.maxspeed=100;
        bus.burnup=45;
        //расчет пути, пройденого 0,5 часа
        double time=0.5;
       System.out.println("автомобиль c"+car.passanegers+"пассажирами");
       car.distance(time);
       System.out.println("автобус с"+bus.passanegers+"пассажирами");
       bus.distance(time);


    }//main(String[])

}//VehicleDemo class

