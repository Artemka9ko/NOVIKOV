package leasting_3;

import static leasting_3.Vehicle11.v;
class Moveable{}

class InstanceDemo {
     public static void main(String[] args){
         Vehicle11.Auto a=new Vehicle11.Auto();
         v=new Vehicle11();
         Vehicle11[] va = new Vehicle11[]{Vehicle11.a,v};
         for (int i=0; i<va.length; i++){
             System.out.println(va[i].toString());
         }//for
     }//main(String[]) method
}//InstanceDemo class
