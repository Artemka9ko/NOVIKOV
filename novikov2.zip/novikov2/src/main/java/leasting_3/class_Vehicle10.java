package leasting_3;

 class Vehicle10 {
     int passanegers;//кол-во пассажиров
     private int wheels;//кол-во колес
     private int maxspeed;//макс скорость
     int burnup;//расход топлива
     //конструктор без параметров
     Vehicle10(){
         this(4,4,160,13);
     }//Vehicle() конструктор
     //конструктор с параметерами
     Vehicle10(int passanegers, int wheels, int maxspeed, int burnup){
         this.passanegers=passanegers;
         this.wheels=wheels;
         this.maxspeed=maxspeed;
         this.burnup=burnup;
     }//Vehicle(int,int,int,int) конструктор
     //мутоды расчета длины пройденного пути
     double distance(int interval){
         return distance((double) interval);
     }//distance(int)
     double distance(double interval){
         double value=this.maxspeed*interval;
         return value;
     }//distance(double

}//Vehicle9 class
