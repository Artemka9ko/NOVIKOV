package leasting_3;

 class Vehicle2 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     int maxspeed;//макс скорость
     int burnup;//расход топлива
     public static void main(String[] args){
         Vehicle2 car1=new Vehicle2();
         car1.passanegers=2;//два пассажира
         car1.wheels=6;//шесть колес
         car1.maxspeed=130;//max. скорость 130 км/ч
         car1.burnup=30;//расход топлива 30 литров на 100 км
         //расчет пути, проходимого за полчаса
         //при движении с максимальной скоростью
         double distance= car1.maxspeed*0.5;
         System.out.println("За полчаса car1 может проехать");
         System.out.println(distance+"км.");
         car1=null;
     }//main(String[])




}//Vehicle class


