package leasting_3;

 class Venicle7 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     private int maxspeed;//макс скорость
     int burnup;//расход топлива
     //конструктор класс Venicle
     Venicle7(int passanegers, int wheels,int maxspeed, int burnup){
         this.passanegers=passanegers;
         this.wheels=wheels;
         this.maxspeed=maxspeed;
         this.burnup=burnup;
     }//Vehicle(int,int,int,int) constructor
     //расчет пройденого пути
     double distance(double interval){
         double val=this.maxspeed*interval;
         return val;
     }//distance(double)Method
}//Vihicle class
class VehicleAccessDemo{
     public static void main(String[] args){
         Venicle7 ferrari=new Venicle7(2,4,360,12);
         double distance=ferrari.distance(0.5);
         System.out.println("Ferrari за пол часа проедет" +distance+ "км.");
         //следущая команда вызовет ошибку компиляции
         //закомментрируйте ее
         //System.out.println("Скорость Ferrari: " +ferrari.maxspeed+ "км/ч");
     }
}