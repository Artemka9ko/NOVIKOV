package leasting_3;

 class Vehicle5 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     int maxspeed;//макс скорость
     int burnup;//расход топлива
     //конструктор с параметрами
     Vehicle5(int p, int w, int ms, int bu){
         passanegers=p;
         wheels=w;
         maxspeed=ms;
         burnup=bu;
     }//Vehicle(int,int,int)
     //расчет длинны пройденого пути
     double distance(double interval){
         double value=maxspeed*interval;
         return value;
     }//distance(double)
}//Vegicle class
class VehicleConstrDemo{
     public static void main(String[] args){
         Vehicle5 car=new Vehicle5(2,4, 130,30);
         Vehicle5 bus=new Vehicle5(45,4,120,25);
         double interval=1;
         double distanceCar= car.distance(interval);
         double distancerBus= bus.distance(interval);
         System.out.println("Автомобиль с " +car.passanegers+ "пассажирами " + " проедет за 1 час " +distanceCar+ " км. ");
         System.out.println("Автобус с " +bus.passanegers+ "пассажирами " + "проедет за 1 час " + distancerBus+ "км.");
     }//main(Stringg[]) method
}//VehicleConstrDemo class