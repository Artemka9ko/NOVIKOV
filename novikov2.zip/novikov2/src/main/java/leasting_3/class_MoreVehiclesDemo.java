package leasting_3;

 class Vehicle1 {
    int passanegers;//кол-во пассажиров
    int wheels;//кол-во колес
    int maxspeed;//макс скорость
    int burnup;//расход топлива
     //объявляем метод,вычисляющий пройденный путь.
     //метод принимает парметр interval, задающий время,
     //и не возвращает никакого значения(void)
     void distance(double interval){
         double value=maxspeed*interval;
         System.out.println("пройденый путь, равный"+value+"км.");
     }//distance(double+interval
}//Vehicle class
class MoreVehiclesDemo{
     public static void main(String[] args){
         //объект car1
         Vehicle1 car1=new Vehicle1();
         car1.passanegers=2;
         car1.wheels=6;
         car1.maxspeed=130;
         car1.burnup=30;
         //другой экземпляр класса Vehicle:объект bus1
         Vehicle1 bus1=new Vehicle1();
         bus1.passanegers=45;
         bus1.wheels=4;
         bus1.maxspeed=100;
         bus1.burnup=45;
         //расчет пути, пройденого 1,25 часа
         double interval=1.25;
         double distanceCar=car1.maxspeed*interval;
         double distanceBus=bus1.maxspeed*interval;
         System.out.println("car1 может проехать за 1 час 15 минут расстояние в");
         System.out.println(distanceCar+"км c"+ car1.passanegers);
         System.out.println("пассажирами.");
         System.out.println("bus1 может проехать за 1 час 25 минут расстрояние в");
         System.out.println(distanceBus+"км c"+bus1.passanegers);
         System.out.println("пассажирами.");


     }//main(String[])

}//VehicleDemo class
