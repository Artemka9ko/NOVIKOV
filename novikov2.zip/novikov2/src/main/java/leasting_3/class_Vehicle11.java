package leasting_3;
//базовый класс Vehicle
class  Vehicle11 {
    public static Vehicle11 a, v;
    //возьмите тело класса из примера 3.11 и добавьте
    //конструктор без праметров из примера 3.15
    int passanegers;//кол-во пассажиров
    private int wheels;//кол-во колес
    private int maxspeed;//макс скорость
    int burnup;//расход топлива
    Vehicle11() {
        this.passanegers=4;
        //кол-во колес
        int wheels = 4;
        //макс скорость
        int maxspeed = 160;
        this.burnup=13;
    }//Vehicle class
    //подкласс (потомок) Auto базого класса Vehicle
    static class Auto{
        public boolean sunroof;

        public String distance(double v){

            return null;
        }


        public String getMaxSpeed(){

            return null;
        }

    }
    class AutoExtendsVehicleDemo{
    }//Auto class
    public class ExtendsVehicleDemo{
        public void main(String[] args){
            //создаем объекта подкласса Auto
            Auto bmw=new Auto();
            bmw.sunroof=true;//люк есть
            //пример обращения к методам и перменным
            //надкласса и подкласса
            System.out.println("Путь, пройденный за 1.5 часа:" +bmw.distance(1.5)+ "км.");
            System.out.println("Мак-ая скорость:" +bmw.getMaxSpeed() +"км.");
            System.out.println("Наличие люка: " +bmw.sunroof);


        }//main(String[]) method
    }
}
