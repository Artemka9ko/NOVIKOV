package leasting_3;


 class Vehicle6 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     int maxspeed;//макс скорость
     int burnup;//расход топлива
     //конструктор
     Vehicle6(int passanegers,int wheels,int maxspeed, int burnup){
         this.passanegers=passanegers;
         this.wheels=wheels;
         this.maxspeed=maxspeed;
         this.burnup=burnup;
     }//Vehicle конструктор
     //расчет пройденного пути
     double distance(double interval){
         double value = this.maxspeed*interval;
         return value;
     }//distance(double) method
}//Vehicle class
