package leasting_3;

 class Vehicle9 {
     int passanegers;//кол-во пассажиров
     private int wheels;//кол-во колес
     private int maxspeed;//макс скорость
     int burnup;//расход топлива
     /* конструктор без параметров,инициализирующий
     ** перменные объекта стандартными значениями*/
     Vehicle9(){
         this.passanegers=4;
         this.wheels=4;
         this.maxspeed=160;
         this.burnup=13;
     }//Vehicle9() конструктор
     /* конструктор с параметрами, инициализирующий
     ** перменные объекта значениями, переданными из вызывающей программы*/
     Vehicle9(int passanegers, int wheels, int maxspeed, int burnup){
         this.passanegers=passanegers;
         this.wheels=wheels;
         this.maxspeed=maxspeed;
         this.burnup=burnup;
     }//Vehicle9(int,int,int,int) constructor

}//Vehicle class
