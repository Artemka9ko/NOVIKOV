package leasting_3;

 class Vehicle8 {
     int passanegers;//кол-во пассажиров
     private int wheels;//кол-во колес
     private int maxspeed;//макс скорость
     int burnup;//расход топлива
     //конструктор класс Vehicle
     Vehicle8(int passanegers, int wheels, int maxspeed, int burnup){
         this.passanegers=passanegers;
         this.setWheels(wheels);
         this.maxspeed=maxspeed;
         this.burnup=burnup;
     }//Vehicle(int,int,int) constructor
     //рачет пройденого пути
     double distance(double interval){
         double val=this.maxspeed*interval;
         return val;
     }//distance(double)method
     //метод чтения значения maxspeed
     int getMaxspeed(){
         return this.maxspeed;
     }
//метод чтения значения кол-ва колес
     int getWheels(){
         return this.wheels;
     }
     //метод записи кол-ва колес
     void setWheels(int wheels){
         //проверяем преданный параметр на корректность
         if ((wheels<1) || (wheels>24)){
             System.out.println("Неверное указано число колес.");
             return;
         }
         this.wheels=wheels;
     }

}//Vehicle class
class VehicleGetSetMethod{
     public static void main(String[] args){
         Vehicle8 ferrari=new Vehicle8(2,-2,360,12);
         System.out.println("мак-ая скорость:" +ferrari.getMaxspeed() + "км/ч");
         System.out.println("Число колес:" +ferrari.getWheels());
     }//main(String[])method
}//VehicleGetSetMethod class

