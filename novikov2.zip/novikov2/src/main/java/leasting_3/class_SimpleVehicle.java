package leasting_3;

 class SimpleVehicle {//упрощеннй вариант класса Vehicle
    int passengers;
}
class RefTypes{
    public static void main(String[] args){
        SimpleVehicle car1, car2; //две ссылки на объект
        //типа SimpleVehicle
        car1=new SimpleVehicle();//создаем объект и ссылку
        //на него
        car1.passengers=25;//задаем кол-во пассажиров
        //обе перменные ссылаются на один объетк
        car2=car1;
        //докажем это:
        System.out.println("Кол-во пассажиров car2 равно"
        +car2.passengers);
        car2.passengers=50;
        //если car2 и car1-это один и тот же объект то теперь
        //car1.passengers стфло равно 50
        System.out.println("Кол-во пассажиров car1 равно"
        +car1.passengers);
    }//main(String[])
}//RefTypes class
