package leasting_3;

 class Venicle4 {
     int passanegers;//кол-во пассажиров
     int wheels;//кол-во колес
     int maxspeed;//макс скорость
     int burnup;//расход топлива
     //объявляем метод, вычисляющий пройденный путь.
     //теперь он возваращет вычисленное значение типа double
     double distance(double interval){
         double value=maxspeed*interval;
         return value;
     }//distance(double interval)
}//Vehicle class
class VehicleRetMethod{
     public static void main(String[] args){
         Venicle4 car=new Venicle4();
         car.passanegers=2;
         car.wheels=4;
         car.maxspeed=130;
         car.burnup=30;
         //другой экзепляр класса Vehicle
         Venicle4 bus=new Venicle4();
         bus.passanegers=45;
         bus.wheels=4;
         bus.maxspeed=130;
         bus.burnup=25;
         //расчет пути пройденного за 0.5 часа
         double time=0.5;
         double distanceCar= car.distance(time);
         double distanceBus= bus.distance(time);
         System.out.println("автомобиль с"+car.passanegers+"пассажирами");
         System.out.println("пройдет за пол часа путь" +distanceCar+"км.");
         System.out.println("автобус с" +bus.passanegers+"пассажирами");
         System.out.println("пройдет за пол часа путь" +distanceBus+"км.");
     }//main(String[])
}//VehicleRetMethod class