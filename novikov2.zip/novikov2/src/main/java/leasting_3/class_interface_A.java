package leasting_3;

 class interfaceA {
     interface A{
         void metodA();// метод А() интерфейс А
     }//A interface
     interface B extends A{
         void metodB();//метод B() интерфейс B
     }//B interface
     class IExample{
         public void metodB() {

         }

         public void metodA() {
         }
     }
     class IExampleImplementsB{
         public void metodA() {System.out.println("Метод А");}
         public void metodB() {System.out.println("Метод B");}
     }//IExample clas
      class IExampleDemo{
         public void main(String[] args) {
             IExample ie = new IExample();
             ie.metodA();//вызов метода интерфейса А
             ie.metodB();//вызов метода интерфейса В
         }

     }//main(String[]) method
}//IExampleDemo class
