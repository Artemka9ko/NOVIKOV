package leasting_2;
//вычисление длинны гипотенузы по теореме Пифагора

public class class_HypotDemo {
    public static void main(String[] args){
        double cathetus1, cathetus2, hypot;
        cathetus1=8;//длинна первого катета
        cathetus2=13;//длинна второго катета
        hypot=Math.sqrt((cathetus1*cathetus1)+(cathetus2*cathetus2));
        System.out.println("длинна гипотенузы равна" +hypot);
    }//main(String[])

}//class HypotDemo
