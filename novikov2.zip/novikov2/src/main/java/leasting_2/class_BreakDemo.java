package leasting_2;

public class class_BreakDemo {
    public static void main(String[] args){
        int max=25;
        for (int n=0; n<25; n++){
            /* цикл выполняется до тех пор, пока квадрат числа n не станет больше 25 */
            if ((n*n) >=25) break;
            System.out.println("n равно"+n+", n в квадрате равно"+n*n);

        }//for
        System.out.println("Конец цикла");
    }//main(String[]) method
}//BreakDemo class
