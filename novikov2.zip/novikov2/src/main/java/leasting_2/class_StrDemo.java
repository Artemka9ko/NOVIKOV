package leasting_2;


public class class_StrDemo {
    public static void main(String[] args){
        //для перевода каретки (начало новой строки)
        //служит код \n
        System.out.println("Первая строка \n Вторая строка");
        //знак тамбуляции помогает оформить выводимый текс
        //в колонки. Он выводится с помощью кода \t
        System.out.println("A\tB\tC");
        System.out.println("D\tE\tF");
    }//main(String[]) method

}//StrDemo class
