package leasting_2;
//пример присвоения значений переменным
public class class_AssignExample {
    public static void main(String[] args){
        //объявляем две перменные
        int var1;
        int var2;
        //присваиваем им значения
        var1=4096;
        var2=var1/4;
        //выводим текущие значения переменных
        System.out.println("var1=" +var1);
        System.out.println("var2=var1/4="+var2);
    }//main()
}//AssignExample class
