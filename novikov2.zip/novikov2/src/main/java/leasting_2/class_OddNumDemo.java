package leasting_2;

public class class_OddNumDemo {
    public static void main(String[] args){
        for (int num=0; num<=10; num++){
            if ((num % 2)==0) continue;
        }
    }//main(String[]) method
}//OddNumDemo class
