package leasting_2;

public class class_AlphabetDoWhileDemo {
    public static void main(String[] args){
        char ch='Я';
        do {
            System.out.println(ch);
            ch--;
        }while (ch>='A');
    }//main(String[])
}//AlphabetDoWhileDemo class
