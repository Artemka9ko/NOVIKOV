package leasting_5;

import java.io.File;

public class class_sameDateToDirFiles {
    public static void sameDateToDirFiles(String dir){
        long modified=System.currentTimeMillis();
        //текущее время(миллисекудны)
        File walkDir=new File(dir);//просматриваемая папка
        String[] dirList=walkDir.list();//список элементов в папке
        //последоватльный просмотр папки
        for (int i=0; i<dirList.length; i++){
            File f=new File(dirList[i]);
            if (f.isDirectory()){
                //элемент является также каталогом, осуществляется
                //рекурсивный вызов метода
                sameDateToDirFiles(f.getPath());
                continue;
            }
            //для файлов устанавливаем дату последнего изменения
            f.setLastModified(modified);
        }//for(int i=o; dirList[i]; i++)
    }//sameDateToDir(String)
}
