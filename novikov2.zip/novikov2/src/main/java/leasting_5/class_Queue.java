package leasting_5;

 class Queue {
     private char q[];
     private int putloc;//входной индекс
     private int getloc;//выходной индекс

     //создание пустой очереди
     Queue(int size) {
         q = new char[size + 1];//резервирование памяти
         getloc = putloc = 0;
     }//Queue(int) constructor

     //создание очереди из другой очереди
     Queue(Queue ob) {
         putloc = ob.putloc;
         getloc = ob.getloc;
         q = new char[ob.q.length];
         //копирование элементов из предыдущей очереди
         System.arraycopy(ob.q, 0, q, 0, ob.q.length);
     }
 //Queue(Queue) constructor
     //создание очереди из массива
     Queue(char a[]) {
         putloc = 0;
         getloc = 0;
         q = new char[a.length + 1];
         //копирование элементов символьного массива в очередь
         for (int i = 0; i < a.length; i++)
             put(a[i]);

}//Queue (char[])
     //проверка переполнения очереди
     boolean isFuul() {
     return (putloc==(q.length - 1));
     }//isFull() method
     //проверка пустоты очереди
     boolean isEmpty(){
     return (getloc==putloc);
     }//isEmpty() method
     //добавление символа в очередь
     void put (char ch) throws  IllegalStateException {
         if ((isFuul())) {
             throw new IllegalStateException("Очередь переполнена");
         }
         putloc++;
         q[putloc] = ch;
     }//put(char)method
     //извлечение символа из очреди
     char get() throws IllegalStateException{
     if (isEmpty()) {
         throw new IllegalStateException("Fronta je рrбzdnб.");
     }
getloc++;
     return q[getloc];

     }//get() method

 }//Queue class





