package leasting_5;

 class QuickSort {
     static void sort(char items[]) {
         QuickSort(items, 0, items.length - 1);

     }//sort(char)

     private static void QuickSort(char items[], int left, int right) {
         int top, bottom;
         char comparand, value;
         top = left; //первая позиция
         bottom = right; //поседняя позиция
         //выбор компаранда- символ из середины массива
         comparand = items[((left + right) / 2)];
         //разделение проследовательности на две части
         do {
             while ((items[top] < comparand) && (top < right)) top++;
             while ((comparand < items[bottom]) &&
                     (bottom > left)) bottom--;
             if (top <= bottom) {
                 value = items[top];
                 items[top] = items[bottom];
                 items[bottom] = value;
                 top++;
                 bottom--;
             }

         }while ( (top <= bottom));


     /*Если закомментированный код включить в программу,
         **будет виден промежуточный результат сортровки
         if((right+1)-left) == items.length){
         for(int i=0; i<items.length; i++)
         System.out.println(items[i]);
         System.out.println();



     }

          */
         //рекрусивная сортировка первой части
         if (left < bottom) QuickSort(items, left, bottom);
         //рекрусивная сортировка второй части
         if (top < right) QuickSort(items, top, right);
     }//QuickSort(char,left,right)
 }//QuickSortDemo
class QuickSortDemo {
     private static void main(String[] args){
         char seq[] = {'h','e','d','a','c','i'};
         System.out.println("Исходный порядрок символов");
         for (int i=0; i<seq.length; i++)
             System.out.println(seq[i]);
         System.out.println();
         QuickSort.sort(seq);
         System.out.print("Сортированный порядрок:");
         for (int i=0; i< seq.length; i++)
             System.out.println();
     }//main(String[]) method
}//QuickSortDemo class
